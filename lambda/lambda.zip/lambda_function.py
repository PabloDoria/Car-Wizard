def lambda_handler(event, context):
    return {"message": "Lambda funcionando correctamente"}
